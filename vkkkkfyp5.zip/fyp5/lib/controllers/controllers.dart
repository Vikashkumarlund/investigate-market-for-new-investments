import 'carousel_controller.dart';

CarouselController carouselController = CarouselController.instance;
