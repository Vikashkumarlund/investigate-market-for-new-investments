class PropertyListModel {
  String name;
  String imgName;

  PropertyListModel({required this.name, required this.imgName});
}
