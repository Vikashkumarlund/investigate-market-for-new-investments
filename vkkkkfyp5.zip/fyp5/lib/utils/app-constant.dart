// ignore_for_file: file_names

import 'package:flutter/material.dart';

class AppConstant {
  static String appMainName = 'Investigate Market for new Investment';
  static const appMainColor = Color(0xffF5591F);
  static const appScendoryColor = Color(0xffF5591F);
  static const appTextColor = Color(0xFFFBF5F4);
  static const appStatusBarColor = Color(0xFFFBF5F4);
}
