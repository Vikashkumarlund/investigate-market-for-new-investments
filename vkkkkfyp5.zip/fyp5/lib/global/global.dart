library globals;

String check = "vehicle";
String navCheck = "vehicle";
