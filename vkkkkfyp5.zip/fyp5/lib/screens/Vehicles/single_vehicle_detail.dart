// ignore_for_file: file_names, must_be_immutable, prefer_const_constructors, prefer_const_literals_to_create_immutables, avoid_unnecessary_containers, prefer_interpolation_to_compose_strings, unused_local_variable, avoid_print

import 'package:cached_network_image/cached_network_image.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../models/cars_model.dart';
import '../../utils/app-constant.dart';
import '../chat/chat_screen.dart';

class SingleVehicleDetailsScreen extends StatefulWidget {
  CarsModel carsModel;
  SingleVehicleDetailsScreen({super.key, required this.carsModel});

  @override
  State<SingleVehicleDetailsScreen> createState() =>
      _SingleVehicleDetailsScreenState();
}

class _SingleVehicleDetailsScreenState
    extends State<SingleVehicleDetailsScreen> {
  String carSpecs = "";
  @override
  void initState() {
    if (widget.carsModel.carMode == "Sell") {
      carSpecs = "  Vehicle Price :  " + widget.carsModel.carPrice.toString();
    } else {
      carSpecs =
          "  Vehicle Rent :  " + widget.carsModel.carInstallment.toString();
    }
  }

  @override
  Widget build(BuildContext context) {
    var list_name = [
      widget.carsModel.imgUrl,
    ];
    return Scaffold(
      appBar: AppBar(
        iconTheme: IconThemeData(color: AppConstant.appTextColor),
        backgroundColor: AppConstant.appMainColor,
        title: Text(
          "Vehicle Details",
          style: TextStyle(color: AppConstant.appTextColor),
        ),
        /*actions: [
          GestureDetector(
            onTap: () => Get.to(() => HomeScreen()),
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Icon(
                Icons.shopping_cart,
              ),
            ),
          ),
        ],*/
      ),
      body: Container(
        child: Column(
          children: [
            //product images

            SizedBox(
              height: Get.height / 60,
            ),
            CarouselSlider(
              items: list_name
                  .map(
                    (imageUrls) => ClipRRect(
                      borderRadius: BorderRadius.circular(10.0),
                      child: CachedNetworkImage(
                        imageUrl: imageUrls,
                        fit: BoxFit.cover,
                        width: Get.width - 10,
                        placeholder: (context, url) => ColoredBox(
                          color: Colors.white,
                          child: Center(
                            child: CupertinoActivityIndicator(),
                          ),
                        ),
                        errorWidget: (context, url, error) => Icon(Icons.error),
                      ),
                    ),
                  )
                  .toList(),
              options: CarouselOptions(
                scrollDirection: Axis.horizontal,
                autoPlay: true,
                aspectRatio: 2.5,
                viewportFraction: 1,
              ),
            ),

            Padding(
              padding: EdgeInsets.all(8.0),
              child: Card(
                elevation: 5.0,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10.0),
                ),
                child: Column(
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Container(
                        alignment: Alignment.topLeft,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            Icon(Icons.title, color: Colors.orange),
                            Text("  Vehicle Brand :  " +
                                widget.carsModel.carBrand),
                          ],
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Container(
                        alignment: Alignment.topLeft,
                        child: Row(
                          children: [
                            Icon(Icons.home, color: Colors.orange),
                            Text("  Vehicle Location :  " +
                                widget.carsModel.carLocation),
                          ],
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Container(
                        child: Row(
                          children: [
                            Icon(Icons.location_city, color: Colors.orange),
                            Text(carSpecs),
                          ],
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Container(
                        child: Row(
                          children: [
                            Icon(Icons.location_city, color: Colors.orange),
                            Text("  Vehicle Mode :  " +
                                widget.carsModel.carMode.toString()),
                          ],
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Container(
                        child: Row(
                          children: [
                            Icon(Icons.location_city, color: Colors.orange),
                            Text(carSpecs),
                          ],
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Container(
                        child: Row(
                          children: [
                            Icon(
                              Icons.photo_size_select_actual,
                              color: Colors.orange,
                            ),
                            Text("  Vehicle Millage :  " +
                                widget.carsModel.carDistance.toString()),
                          ],
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Container(
                        child: Row(
                          children: [
                            Icon(
                              Icons.price_change,
                              color: Colors.orange,
                            ),
                            Text("  Vehicle Desciption :  " +
                                widget.carsModel.carDesciption),
                          ],
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Container(
                        child: Row(
                          children: [
                            Icon(
                              Icons.info_outline_rounded,
                              color: Colors.orange,
                            ),
                            Text(" Seller Information  :"),
                          ],
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Container(
                        child: Row(
                          children: [
                            Icon(
                              Icons.sell,
                              color: Colors.orange,
                            ),
                            Text("  Seller Name :  " +
                                widget.carsModel.carSellerName),
                          ],
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Container(
                        child: Row(
                          children: [
                            Icon(
                              Icons.phone,
                              color: Colors.orange,
                            ),
                            Text("  Seller Phone :  " +
                                widget.carsModel.carSellerPhone.toString()),
                          ],
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Material(
                            child: Container(
                              width: Get.width / 3.0,
                              height: Get.height / 16,
                              decoration: BoxDecoration(
                                color: AppConstant.appScendoryColor,
                                borderRadius: BorderRadius.circular(20.0),
                              ),
                              child: TextButton(
                                child: Text(
                                  "Chat",
                                  style: TextStyle(
                                      color: AppConstant.appTextColor),
                                ),
                                onPressed: () {
                                  //for navigating to chat screen
                                  Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (_) => ChatScreen(
                                                userId:
                                                    widget.carsModel.sellerId,
                                                sellerName: widget
                                                    .carsModel.carSellerName,
                                              )));
                                  //sellerName: widget
                                  //                                                   .carsModel.carSellerName
                                  // Get.to(() => SignInScreen());
                                },
                              ),
                            ),
                          ),
                          SizedBox(
                            width: 5.0,
                          ),
                          Material(
                            child: Container(
                              width: Get.width / 3.0,
                              height: Get.height / 16,
                              decoration: BoxDecoration(
                                color: AppConstant.appScendoryColor,
                                borderRadius: BorderRadius.circular(20.0),
                              ),
                              child: TextButton(
                                child: Text(
                                  "Direct Call",
                                  style: TextStyle(
                                      color: AppConstant.appTextColor),
                                ),
                                onPressed: () {
                                  // Get.to(() => SignInScreen());

                                  //await checkProductExistence(uId: user!.uid);
                                },
                              ),
                            ),
                          ),
                        ],
                      ),
                    )
                  ],
                ),
              ),
            )
          ],
        ),
      ),
    );
  }
}
