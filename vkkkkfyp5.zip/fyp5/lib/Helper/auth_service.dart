class AuthService {
  static bool authenticated = true;
}
