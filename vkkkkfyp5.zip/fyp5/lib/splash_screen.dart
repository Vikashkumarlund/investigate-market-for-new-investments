import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:fyp5/Navigation/nav_vehicle.dart';
import 'package:fyp5/screens/Authentication/LogIn.dart';
import 'package:fyp5/screens/Authentication/Signup.dart';
import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});
  @override
  State<StatefulWidget> createState() => Initstate();
}

class Initstate extends State<SplashScreen> {
  @override
  void initState() {
    sharedPreferencesRoute();

    // TODO: implement initState
    super.initState();
  }

  startTimer() async {
    var duration = Duration(seconds: 1);
    return new Timer(duration, navigatetohome());
  }

  sharedPreferencesRoute() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    var email = prefs.getString('email');
    print(email);
    if (email == null) {
      //startTimer();
      navigatetohome();
    } else {
      Get.to(NavVehicle());
    }
  }

  signupRoute() {
    Navigator.pushReplacement(
        context, MaterialPageRoute(builder: (context) => SignUpScreen()));
  }

  navigatetohome() {
    // await Future.delayed(const Duration(milliseconds: 2000), (() {}));

    User? user = FirebaseAuth.instance.currentUser;
    FirebaseFirestore.instance
        .collection('users')
        .doc(user?.uid)
        .get()
        .then((DocumentSnapshot documentsnapshot) {
      if (documentsnapshot.exists) {
        Get.to(() => LoginScreen());
      } else {
        Get.to(() => SignUpScreen());
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return initWidget();
  }

  Widget initWidget() {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      body: Stack(
        children: [
          Center(
            child: Container(
              height: 250,
              width: 250,
              decoration: BoxDecoration(
                image: const DecorationImage(
                    image: AssetImage("assets/investor.png"),
                    fit: BoxFit.cover),
              ),
            ),
          ),
          /*Center(
            child: Container(
                height: 200,
                width: 200,
                child: Image.asset("assets/investor.png")),
          )*/
        ],
      ),
    );
  }
}
